//
//  ScoreKeeper.swift
//  MatchMatch
//
//  Created by Benjamin Kim on 4/22/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import Foundation

class ScoreKeeper {
    let NUM_TOP = 5
    
    var scoreData:String! 
    var url: URL
    var scores: [Int]

    
    init(usingFile file: String){
        let docsDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        self.url = docsDir.appendingPathComponent(file).appendingPathExtension("plist")
        self.scores = [1,2,3,4,5]
    }
    
    func readScores() {
        if let retrievedData = try? Data(contentsOf: url) {
            let decoder = PropertyListDecoder()
            if let scoresFromFile = try? decoder.decode([Int].self, from: retrievedData) {
                scores = scoresFromFile
            }
        }
    }
    
    func writeScores() {
        let encoder = PropertyListEncoder()
        if let encodedScores = try? encoder.encode(scores) {
            try? encodedScores.write(to: url, options: .noFileProtection)
        }
    }
    
    func addScore(newScore: Int) {
        scores = (scores+[newScore]).sorted().reversed()
        if (scores.count > self.NUM_TOP) {
            scores = Array(scores[0..<self.NUM_TOP])
        }
    }
    
    func getScores() -> [Int] {
        return self.scores
    }
}
