//
//  HighScoresViewController.swift
//  MatchMatch
//
//  Created by Benjamin Kim and Victoria Lo on 4/11/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import UIKit

class HighScoresViewController: UIViewController { //displays the highscores of users and is saved.
    var num: Int = 0 // init num to be used in adding new scores from previous VC
    @IBOutlet weak var outputLabel: UILabel! // where all the highscores are going to be

    @IBAction func doneButtonAction(_ sender: UIButton) { // takes you back to the themes view controller
        self.performSegue(withIdentifier: "unwindToViewController1", sender: self)
    }
    
    var scores = ScoreKeeper(usingFile: "scores")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scores.readScores()
        updateDisplay()
        newGameScore() // this function is for adding the scores from the previous VC


    }
    func newGameScore(){
        scores.addScore(newScore: num) // we are segueing the finalCount from the previous VC and using it to add to the highscores. 
        updateDisplay()
        scores.writeScores()
        }
    
    
    func updateDisplay() {
        var message = ""
        let scoreList = scores.getScores()
        for i in 1...scoreList.count {
            message += "\(i). \(scoreList[i-1]) \n\n"
        }
        outputLabel.text = message
    }

    

}
