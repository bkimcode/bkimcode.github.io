//
//  ThemesViewController.swift
//  MatchMatch
//
//  Created by Benjamin Kim and Victoria Lo on 4/11/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import UIKit

class ThemesViewController: UIViewController, UISplitViewControllerDelegate {
    
    @IBAction func prepareForUnwind(segue: UIStoryboardSegue) {
        
    }
    
    
    // emojis will be used in the cards to represent the different themes.
    let themes = [
        "Sports": "⚽️🏀🏅⛷🏏🏓⛳️🏆🥋🏂🏑🏒🏉🎾⚾️",
        "Animals": "🐶🦊🦁🐸🐯🐣🐳🐠🦉🐹🐭🐱🙈🐧🐔",
        "Food": "🍎🥐🌶🍆🥑🍒🍑🍅🍇🍉🍌🍋🍏🍊🥕"
    ]
    
    override func awakeFromNib() { // function is required since the user is making changes to match their preferences.
        splitViewController?.delegate = self
    }
    
    func splitViewController(_ splitViewController: UISplitViewController,
                             collapseSecondary secondaryViewController: UIViewController,
                             onto primaryViewController: UIViewController) -> Bool {
        //  used splitViewController so that users can switch between themes mid game without having to restart the app entirely.
        if let cvc = secondaryViewController as? ConcentrationViewController {
            if cvc.theme == nil {
                return true // Screen stays the same since a theme has not been selected
            }
        }
        return false // collapses since theme has been selected.
    }
    
    private var concentrationLiveViewController: ConcentrationViewController? {
        // It'll return if it's able to find a concentrationLiveVC game inside the splitVC
        return splitViewController?.viewControllers.last as? ConcentrationViewController
    }
    
    @IBAction func changeTheme(_ sender: Any) {
        
        if let cvc = concentrationLiveViewController {
            //If I'm in the menu and I select my theme --> set the theme
            if let themeName = (sender as? UIButton)?.currentTitle, let theme = themes[themeName] {
                cvc.theme = theme
            }
        } else if let cvc = lastSeguedToConcentrationViewController {
            // If I'm in a game, make sure the theme matches what I had selected
            if let themeName = (sender as? UIButton)?.currentTitle, let theme = themes[themeName] {
                cvc.theme = theme
            }
            // lets the user go back just incase they selected the wrong theme so that they can chose theme without having to restart the game, or create another instance of the game.
            navigationController?.pushViewController(cvc, animated: true)
        } else {
            // Segue directly from themeVC to concentrationVC so that we can adjust the segue through code.
            performSegue(withIdentifier: "ChangeTheme", sender: sender)
            
        }
        
    }
    

    
    private var lastSeguedToConcentrationViewController: ConcentrationViewController?
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ChangeTheme" {
            if let themeName = (sender as? UIButton)?.currentTitle, let theme = themes[themeName] {
                if let cvc = segue.destination as? ConcentrationViewController {
                    cvc.theme = theme
                    lastSeguedToConcentrationViewController = cvc
                    // anytime a segue is successful, hold a strong ref to it so that if a user wants to pause (go back) they can still continue the game.
                }
            }
        }
    }
    
    
}
