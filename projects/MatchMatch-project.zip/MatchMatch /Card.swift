//
//  Card.swift
//  MatchMatch
//
//  Created by Benjamin Kim and Victoria Lo on 4/11/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import Foundation // card struct to be used with game

struct Card: Hashable { //use hashes because it makes it easier to compare the data and it can be used for index in the main VC
    
    var hashValue: Int {return identifier} // delegate var. req. for Hashable protocol
    
    static func ==(lhs: Card, rhs: Card) -> Bool { // delegate method required for Equatable protocol
        return lhs.identifier == rhs.identifier
    }
    
    // Didn't put associated emoji since model needs to be UI independent
    var isFaceUp = false
    var isMatched = false
    private var identifier: Int
    
    private static var uniqueIdentifier: Int = -1
    
    private static func getUniqueIdentifier() -> Int {
        uniqueIdentifier += 1
        return uniqueIdentifier
    }
    
    init() {
        self.identifier = Card.getUniqueIdentifier()
    }
}
