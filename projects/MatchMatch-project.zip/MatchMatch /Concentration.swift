//
//  Concentration.swift
//  MatchMatch
//
//  Created by Benjamin Kim and Victoria Lo on 4/11/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import Foundation

struct Concentration { //set as struct so that it doesn't get passed around and stays in our VC, can call cards for display, but only I can set specific properties like isMatched. So basically like let call for others.

    private var indexOfOneAndOnlyFaceUpCard: Int? {
        get {
            return cards.indices.filter { cards[$0].isFaceUp }.oneAndOnly
        }
        
        set {
            // Turn all cards face-down, except the card at index of newValue
            for index in cards.indices {
                cards[index].isFaceUp = (index ==  newValue)
                print(cards[index])
            }
        }
    }
    private(set) var cards = [Card]()
    private var numberOfPairsOfCards: Int = -1
    init(numberOfPairsOfCards: Int) {
        assert(numberOfPairsOfCards > 0, "Concentration.init(numberOfPairsOfCards: \(numberOfPairsOfCards)): you must have at least one pair of card")
        self.numberOfPairsOfCards = numberOfPairsOfCards
        reset()
    }
    
    
    mutating func reset() {
        cards = reset(self.numberOfPairsOfCards)
    }
    
    private func reset(_ numberOfPairsOfCards: Int) -> [Card] {
        var shuffledCards = [Card]()
        for _ in 0..<numberOfPairsOfCards {
            let card = Card()
            shuffledCards += [card, card]
        }
        // TODO: shuffle the cards
        shuffledCards = shuffle(shuffledCards)
        return shuffledCards
    }
    
    private func shuffle(_ cards: [Card]) -> [Card] {
        var temp = cards
        var result = [Card]()
        var index = temp.count - 1
        while index >= 0 {
            let randomCard = temp.remove(at: Int(arc4random_uniform(UInt32(index))))
            result.append(randomCard)
            index -= 1
        }
        return result
    }
 //Logic of the game
    mutating func chooseCard(at index: Int) {
        assert(cards.indices.contains(index), "Concentration.chooseCard(at: \(index)): chosen index not in cards") // protects you from negative numbers
        
        if !cards[index].isMatched { // Ignore matched pairs of cards
            
            // THREE POSSIBILE SCENARIOS:
            // 1. 1 card is face up --> see if their IDs match
            // 2. No cards are face up --> flip this tapped card up
            // 3. 2 Cards are faced up (matching or not matching) --> Flip both cards face down
            
            if let matchIndex = indexOfOneAndOnlyFaceUpCard, matchIndex != index { // 1) We HAVE only 1 face-up card. And tapped card isn't the same oneAndOnlyFaceUpCard which the user just tapped a few seconds ago.
                
                // Check if cards match
                if cards[matchIndex] == cards[index] {
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                    print("matched!!!")
                }
                cards[index].isFaceUp = true
            } else {
                // 2 & 3) Either no card or 2 cards face-up
                indexOfOneAndOnlyFaceUpCard = index
            }
            
        }
        // Don't do anything when the tapped card has been matched is already taken out of the game (can't see in UI)
    }    
}


// Looks at all the elements in the Collection calling this computed var. Returns the element if it's the one and only element in the Collection; else return nil.
extension Collection { // Collection is a generic type
    var oneAndOnly: Element? {
        //count & first are Collection methods, so I can use them in the implementation of a Collection var
        return count == 1 ? first : nil
        
    }
}

