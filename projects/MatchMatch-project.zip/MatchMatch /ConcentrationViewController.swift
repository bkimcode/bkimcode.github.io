//
//  ConcentrationViewController.swift
//  MatchMatch
//
//  Created by Benjamin Kim and Victoria Lo on 4/11/18.
//  Copyright © 2018 Benjamin Kim. All rights reserved.
//

import UIKit

class ConcentrationViewController: UIViewController {
    private var cardSelected: Bool = false //Is a card selected?
    private var finished: Bool = false // Is the game finished?
    private var emojisForRandom: String? // Emojis to be randomly set
    private lazy var game : Concentration = {
        return Concentration(numberOfPairsOfCards: numberOfPairsOfCards)
    }() // lazy var so that it only runs if it's requested, if we don't request -> don't run
        // also saves processing time
    
    @IBAction func submitButtonAction(_ sender: UIButton) {
    }// used to submit your score onto the highscores
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if segue.destination is HighScoresViewController //brings data from this VC to next VC
        {
            calculateScore() // get the proper finalScore
            let vc = segue.destination as? HighScoresViewController // if the next VC is the one we're looking for
            vc?.num = finalScore // set variable num in that vc to equal finalScore from this VC
            restartGame() // Restarts the game after user presses submit
        }
    }
    
    // total number of pairs of cards
    var numberOfPairsOfCards: Int {
        return (cardButtons.count + 1) / 2
    }
    // initializing the number of matched pairs to 0, once there is change in variable, it runs the functions to update the paircount function and state of the restart button.
    private(set) var pairCount = 0 {
    didSet {
        updatePairCountLabel()
        updateRestartButton()
    }
    }
    private(set) var flipCount = 0 { //initializes the number of flipped cards to 0, as soon as there is change it runs the updateFlipCountLabel function.
        didSet {
            updateFlipCountLabel()
            
        }
    }

    private(set) var finalScore = 0 { //initializes the final score to 0, as soon as final score changes, it runs updateFinalScoreLabel function.
        didSet{
            updateFinalScoreLabel()
        }
    }
        
    
    @IBOutlet private weak var restartButton: UIButton!{ // when the state of the restart button changes, run those functions.
        didSet{
            updateRestartButton()
            updateFlipCountLabel()
            updatePairCountLabel()
            updateFinalScoreLabel()
        }
    }
    
    private func calculateScore(){ //calculates the final score based on how much time they had left, vs the amount of times they flipped cards
        if finished{
            finalScore = (5 * Int(secLabel.text!)!) / (flipCount/2)
            
    }
    }

    
    @IBOutlet weak var minLabel: UITextField! // minutes for the timer
    @IBOutlet weak var secLabel: UITextField! // seconds for the timer
    
    var timer: Timer! // timer object
    
    
    
    
    
    @IBOutlet private weak var finalScoreLabel: UILabel!{ // when there is a change in final score, run the function
        didSet{
            updateFinalScoreLabel()
        }
    }
    
    private func updateFinalScoreLabel() { // updates the score based on the value of the finalScore Int
        let attributes: [NSAttributedStringKey: Any] = [
            .strokeWidth: 5.0,
            .strokeColor: #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ]
        
            let attributedString = NSAttributedString(string:"Score: \(finalScore)", attributes: attributes)
            finalScoreLabel.attributedText = attributedString
        
        }


    
    
    private func updateRestartButton() { //sets the state of the restart button. if I'm in the middle of a game but want to restart, or if I finish the game but want to restart. In order to restart, you must have flipped ATLEAST 1 card.
        let attributes: [NSAttributedStringKey: Any] = [
            .strokeWidth: 5.0,
            .strokeColor: #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ]
        if flipCount != 0 && pairCount < 5{
            let attributedString = NSAttributedString(string:"Restart!", attributes: attributes)
            restartButton.setAttributedTitle(attributedString, for: .normal)
            restartButton.isUserInteractionEnabled = true
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) { [weak self] in
                self?.reloadCards()
            }
        }else if pairCount == 5{
            let attributedString = NSAttributedString(string:"Restart!", attributes: attributes)
            restartButton.setAttributedTitle(attributedString, for: .normal)
            restartButton.isUserInteractionEnabled = true
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) { [weak self] in
                self?.reloadCards()
                self?.calculateScore()
                self?.finished = true
        }
        }
    }
    
    
    private func updatePairCountLabel() { //updates the pairCountLabel with the amount of pairs matched using pairCount InT
        let attributes: [NSAttributedStringKey: Any] = [
            .strokeWidth: 5.0,
            .strokeColor: #colorLiteral(red: 0.9999960065, green: 1, blue: 1, alpha: 1)
        ]
        let attributedString = NSAttributedString(string:"Pairs: \(pairCount)", attributes: attributes)
            pairCountLabel.attributedText = attributedString

        }
    
    
    @IBOutlet private weak var pairCountLabel: UILabel!{ // When pairCountLabel changes, run the funtion.
        didSet {
            updatePairCountLabel()
        }
    }
    
    private func updateFlipCountLabel() { // updates the number of flips represented through Int flipCount.
        let attributes: [NSAttributedStringKey: Any]? = [
            .strokeWidth: 5.0,
            .strokeColor: UIColor.gray
        ]
        let attributedString = NSAttributedString(string: "Flips: \(flipCount)", attributes: attributes)
        flipCountLabel.attributedText = attributedString
    }
    

    @IBOutlet private weak var flipCountLabel: UILabel! { // when there is a change to flipCount, run the function.
        didSet {
            updateFlipCountLabel()
        }
    }
    
    @IBOutlet private var cardButtons: [UIButton]! // all the buttons (cards)  in the view
    

    @IBAction private func touchCard(_ sender: UIButton) { // when I flip the first card start the game timer, add 1 to the flip counter
        gameTimer()
        cardSelected = true
        flipCount += 1
        guard let cardNumber = cardButtons.index(of: sender) else{
            print("Oops")
            return
        }
        
        game.chooseCard(at: cardNumber) // if the two cards match, add 1 to pairCount which is number of matched pairs, also update the states of the cards
        if game.cards[cardNumber].isMatched { 
            pairCount += 1
            updateViewFromModel()
        }
        reloadCards()
        calculateScore()
    }
    
    
    
    //starts and stops the timer
    private func gameTimer() {
        if flipCount == 1 && finished == false{
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTime), userInfo: nil, repeats: true)
        }else if finished == true{
            timer.invalidate()
        }
    }
    
    
    
    
    
    //checks to see if timer is equal to 0:00
    private func checkTime() {
        if Int(minLabel.text!)! == 0 && Int(secLabel.text!)! == 0 {
            finished = false
        }else{
            finished = true
            timer.invalidate()
        }
    }

    
    // sets the functionality of the timer makes it count down.
    @objc func updateTime() {
        var minutes = Int(minLabel.text!)!
        var seconds = Int(secLabel.text!)!
        
        if minutes == 0 && seconds == 0 {
            timer.invalidate()
        }
        else if seconds == 0 {
            minutes -= 1
            seconds = 59
        }
        else if minutes == 0 {
            seconds -= 1
        }
        
        minLabel.text = String(minutes)
        if seconds < 10 {
            secLabel.text = "0" + String(seconds)
        } else {
            secLabel.text = String(seconds)
        }
    }
    
    override func viewDidLoad() { //start a fresh game when you load
        super.viewDidLoad()
        restartGame()
    }
    
    @IBAction private func restartGame() { // restart function resets the game to original state.
        print("let's play!!!")
        flipCount = 0
        pairCount = 0
        finalScore = 0
        finished = false
        emojisForRandom = theme
        game.reset()
        reloadCards()
        calculateScore()
        minLabel.text = "1"
        secLabel.text = "0"
        
        
        restartButton.isUserInteractionEnabled = false
    }
    private func reloadCards() { // if the game is finished all the cards should be black, if the game isnt finished, unmatched cards are blue while matched pairs are black.
        for index in cardButtons.indices {
            let btn = cardButtons[index]
            let card = game.cards[index]
            if finished {
                flip(for: btn,
                     with: "",
                     backgroundColor: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))
            } else {
                flip(for: btn,
                     with: card.isFaceUp ? emoji(for: card) : "",
                     backgroundColor: card.isFaceUp ? #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1) : (card.isMatched ? #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1) : #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)))
            }
        }
    }
    
    private func updateViewFromModel() { // if cards are faced up show emoji, if they are faced down either show blue for unmatched pairs, or black for matched cards.
        if cardButtons != nil {
            for index in cardButtons.indices {
                let button = cardButtons[index]
                let card = game.cards[index]
                 if card.isFaceUp {
                    button.setTitle(emoji(for: card), for: UIControlState.normal)
                    button.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
                 } else {
                    button.setTitle("", for: UIControlState.normal)
                    button.backgroundColor = card.isMatched ? #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 0) : #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
                }
            }
        }
    }
    
    private func flip(for button: UIButton, with emoji: String, backgroundColor bgColor: UIColor) { // sets the timing of the card flip animation
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationCurve(.easeInOut)
        UIView.setAnimationDuration(0.35)
        
        button.setTitle(emoji, for: .normal)
        button.backgroundColor = bgColor
        
        UIView.commitAnimations()
    }

   
    private var emojiChoices = "🎃🦇🍎😱🙀😈👻🍬" // preset value for emoji choices when there is no theme selected.
    var theme: String? { //sets the emoji to match the ones in theme
        didSet {
            emojiChoices = theme ?? ""
            emoji = [:] // reset dict to be loaded JIT in emoji(for card:)
            updateViewFromModel()
        }
    }
    var emoji = [Card: String]()
    
    func emoji(for card: Card) -> String {
        //randomizes the cards so that it's different everytime.
        if emoji[card] == nil, emojiChoices.count > 0 { //If the game messes up and is unable to pull emoji's, it will return ?
            let randomStringIndex = emojiChoices.index(emojiChoices.startIndex, offsetBy: emojiChoices.count.arc4random)
            emoji[card] = String(emojiChoices.remove(at: randomStringIndex))
        }
        return emoji[card] ?? "?"
    }
}

extension Int {
    // Returns a random number between 0 and the Int
    var arc4random: Int {
        if self > 0 {
            return Int(arc4random_uniform(UInt32(self)))
        } else if self < 0 { // so it won't crash if called by a negative Int.
            return -Int(arc4random_uniform(UInt32(abs(self))))
        } else {
            return 0
        }
    }
}

