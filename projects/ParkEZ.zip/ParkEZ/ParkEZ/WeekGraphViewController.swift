//
//  WeekGraphViewController.swift
//  ParkEZ
//
//  Created by Nguyen, Cong D on 12/2/19.
//  Copyright © 2019 Benjamin Kim. All rights reserved.
//

import UIKit
import Charts

class WeekGraphViewController: UIViewController {
    
    @IBOutlet weak var barChart: BarChartView!
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    @IBOutlet weak var backButton: UIButton!
    
    @IBOutlet weak var graphHeight: NSLayoutConstraint!
    
    var entries : [Int] = [] // An array storing the total number of entries for each day in a chosen week
    var exits: [Int] = [] // An array storing the total number of exits for each day in a chosen week
    var date: [String] = [] // An array storing the specific dates of the chosen week
    var label_Name = "Weekly Entries"
    
    var dateName: [String] = ["Sunday","Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    
    weak var axisFormatDelegate: IAxisValueFormatter? // this is used to modify the x-axis
    
    override func viewDidLoad() {
        super.viewDidLoad()
        changeHeight()
        
        // Do any additional setup after loading the view.
        setChart(values: entries, labelName: label_Name)
    }
    
    
    // This function happens when the user choose select an option
    // If Entries is chosen, display the entries bar chart
    // If Exits is chosen, display the exits bar char
    @IBAction func changeGraph(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            label_Name = "Weekly Entries"
            setChart(values: entries, labelName: label_Name)
        case 1:
            label_Name = "Weekly Exits"
            setChart(values: exits, labelName: label_Name)
        default:
            break
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        changeHeight()
    }
    
    // Change the height of the bar chart based on the device's current orientation
    func changeHeight() {
        if UIDevice.current.orientation.isPortrait{
            print("Portrait")
            // print(self.graphHeight.constant)
            self.graphHeight.constant = 500
        }
        else{
            print("Landscape")
            // print(self.graphHeight.constant)
            self.graphHeight.constant = 280
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // This functions draw a bar chart.
    // The values array is used to generate the bars of the bar charts
    func setChart(values: [Int], labelName: String) {
        barChart.noDataText = "No data available!"
        
        var dataEntries: [BarChartDataEntry] = []
        for i in 0..<values.count {
            //print("chart point : \(values[i])")
            let dataEntry = BarChartDataEntry(x: Double(i), y: Double(values[i]))
            
            dataEntries.append(dataEntry)
        }
        let bar1 = BarChartDataSet(entries: dataEntries, label: labelName)
        let data = BarChartData(dataSet: bar1)
        barChart.data = data
        
        barChart.xAxis.valueFormatter = self
        barChart.xAxis.centerAxisLabelsEnabled = false
        barChart.xAxis.labelPosition = .bottom
        barChart.xAxis.drawLabelsEnabled = true
        barChart.xAxis.drawLimitLinesBehindDataEnabled = true
        barChart.xAxis.avoidFirstLastClippingEnabled = true
        bar1.colors = [NSUIColor.red]
        
        
    }
    
    // A segue to send the array of dates to the previous screen
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let button = sender as! UIButton
        if(button == backButton){
            let driver = segue.destination as! WeekView
            driver.pickerData = date
        }
    }
    
}

// This extension is used to change the label of the x-axis
extension WeekGraphViewController: IAxisValueFormatter {
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return dateName[Int(value) % dateName.count]
    }
}
