//
//  ViewController.swift
//  ParkEZ
//
//  Created by Benjamin Kim on 10/21/19.
//  Copyright © 2019 Benjamin Kim. All rights reserved.
//

import UIKit
import Foundation


class ViewController: UIViewController, UITextFieldDelegate {
    
    
    //object to be put in array to be referenced
    struct instance : Decodable { let Date: String; let Time:String; let Spots:Int }
    
    @IBOutlet weak var label: UILabel! //this is for date
    @IBOutlet weak var openSpots: UILabel! // display the description of open spots
    
    @IBOutlet weak var openSpot: UILabel! // display number of open spots at a specified time
    
    var receiver:String! // the date that the user wants to inspect
    @IBOutlet weak var dateObject: UIDatePicker!
    
    
    var test = [ViewController.instance]()
    
    
    @IBOutlet weak var graphBtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //load the selected date from 1st screen as label
        self.label?.text = "Harper Parking Lot - " + receiver
        //getCurrentDate()
        //self.field.delegate = self
        
        
        
        //path for plist
        let url = Bundle.main.url(forResource:"Data", withExtension: "plist")!
        //gets plist content
        let data = try! Data.init(contentsOf: url)
        //gets the data and decodes it to match struct
        let array = try! PropertyListDecoder().decode([instance].self, from: data)
        //puts the data into array
        //let AR: Array = array
        test = array

    }
    
    //closes keyboard when user is finished entering time
    func textFieldShouldReturn(_ field: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }


    
    
    // Everytime the person changes the picker, the openSpot label will change accordingly.
    @IBAction func timePicker(_ sender: UIDatePicker) {
         let dateFormatter = DateFormatter()
                      dateFormatter.dateStyle = .none
                      dateFormatter.timeStyle = .short
                      let strCurrentDate = receiver.description
                      // print(strCurrentDate)
               let strDate = dateFormatter.string(from: dateObject.date)
                      // print(strDate)
                      
                      for instance in test {
                          let enterTime = instance.Time //time entered
                          let spot = instance.Spots //spots remaining
                          let date = instance.Date // current date
                          
                          if date == strCurrentDate{
                              if enterTime == strDate{
                                  openSpot.text = "Open Spots: " + "\(spot)"
                                  // print(spot)
                                  let myInt = Int(spot)
                                  if(myInt >= 100){
                                      openSpots.text = "There are lots of open spots!"
                                  }
                                  else if(myInt == 0){
                                      openSpots.text = "The lot is full"
                                  }
                                  else if(myInt == 448){
                                      openSpots.text = "The lot is empty"
                                  }
                                  else{
                                      openSpots.text = "There are still some spots left. Hurry!"
                                  }
                              }
                          }
                      }
    }
    
    
    //    //get data from CSV and put it into a 2D array
    //    func csv(data: String) -> [[String]] {
    //        var result: [[String]] = []
    //        let rows = data.components(separatedBy: "\n")
    //        for row in rows {
    //            let columns = row.components(separatedBy: ";")
    //            result.append(columns)
    //        }
    //        return result
    //    }
    //
    //
    //    //read in CSV file into swift
    //    func readDataFromCSV(fileName:String, fileType: String)-> String!{
    //            guard let filepath = Bundle.main.path(forResource: fileName, ofType: fileType)
    //                else {
    //                    return nil
    //            }
    //            do {
    //                var contents = try String(contentsOfFile: filepath, encoding: .utf8)
    //                contents = cleanRows(file: contents)
    //                return contents
    //            } catch {
    //                print("File Read Error for file \(filepath)")
    //                return nil
    //            }
    //        }
    
    
    
    
    //  //test function for accessing plist
    //    func readPropertyList() {
    //        let path = Bundle.main.path(forResource: "Data", ofType: "plist")!
    //        let url = URL(fileURLWithPath: path)
    //        let data = try! Data(contentsOf: url)
    //        let plist = try! PropertyListSerialization.propertyList(from: data, options: .mutableContainers, format: nil)
    //
    //    }
    
    //    //cleans up CSV file
    //    func cleanRows(file:String)->String{
    //        var cleanFile = file
    //        cleanFile = cleanFile.replacingOccurrences(of: "\r", with: "\n")
    //        cleanFile = cleanFile.replacingOccurrences(of: "\n\n", with: "\n")
    //        //        cleanFile = cleanFile.replacingOccurrences(of: ";;", with: "")
    //        //        cleanFile = cleanFile.replacingOccurrences(of: ";\n", with: "")
    //        return cleanFile
    //    }
    
    // Displaying the date on the top label
    func getCurrentDate(){
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let date = formatter.string(from: Date())
        label.text = "Date: " + date
        
    }
    
    
    //gets the day of the week (Monday,Tuesday,etc.) and returns the int value representation where 2-6 is weekday, 1 and 7 are weekends
    func getDayOfWeek(_ today:String) -> Int? {
        let formatter  = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        guard let todayDate = formatter.date(from: today) else { return nil }
        let myCalendar = Calendar(identifier: .gregorian)
        let weekDay = myCalendar.component(.weekday, from: todayDate)
        return weekDay
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let button = sender as! UIButton
        if(button == graphBtn){
            let driver = segue.destination as! SecondView
            
            let whatToPass = receiver
            
            driver.dateLookUp = whatToPass
        }
    }
    
}
