//
//  SecondView.swift
//  ParkEZ
//
//  Created by Benjamin Kim on 10/23/19.
//  Copyright © 2019 Benjamin Kim. All rights reserved.
//

import UIKit
import Charts

class SecondView: UIViewController {
    @IBOutlet weak var lineChart: LineChartView!
    
    struct instance : Decodable { let Date: String; let Time:String; let Spots:Int }
    
    var numspots : [Double] = [] // An array storing the number of available spots for the specified day
    
    var times: [String] = [] // An array storing the times of the day
    
    var dateLookUp: String! // the date that the graph is based on
    
    weak var axisFormatDelegate: IAxisValueFormatter? // This is used for the modification of the x-axis
    
    @IBOutlet weak var graphDate: UILabel! // a label for displaying the date that the graph is based on

    
    @IBOutlet weak var graphHeight: NSLayoutConstraint!
    
    @IBOutlet weak var backbutton: UIButton! // The button that goes back to the previous screen (day look up information screen)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        changeHeight()
        
        // Do any additional setup after loading the view, typically from a nib.
        //path for plist
        let url = Bundle.main.url(forResource:"Data", withExtension: "plist")!
        //gets plist content
        let data = try! Data.init(contentsOf: url)
        //gets the data and decodes it to match struct
        let array = try! PropertyListDecoder().decode([instance].self, from: data)
        //puts the data into array
        let AR: Array = array
        
        graphDate.text = dateLookUp + " Graph"
        
        for i in 0..<AR.count{
            let ar = AR[i]
            if(ar.Date == dateLookUp){
                if(i%2 != 1){
                    let spot = Double(ar.Spots)
                    numspots.append(spot)
                    times.append(ar.Time)
                    // print(spot)
                }
            }
            
        }
        
        // for i in 0..<numspots.count{
        //    print("Date: \(times[i])" + " Spots: \(numspots[i])")
        // }
        
        setChart(values: numspots)
        
    }
    
    // When the device rotate, change the height of the graph
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        changeHeight()
    }
    
    // Change the height of the line chart based on the device's current orientation
    func changeHeight() {
        if UIDevice.current.orientation.isPortrait{
            print("Portrait")
            // print(self.graphHeight.constant)
            self.graphHeight.constant = 500
        }
        else{
            print("Landscape")
            // print(self.graphHeight.constant)
            self.graphHeight.constant = 280
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // This function will draw a line charts.
    // Each element of the values array are used to plot the line chart.
    func setChart(values: [Double]) {
        lineChart.noDataText = "No data available!"
        
        var dataEntries: [ChartDataEntry] = []
        for i in 0..<values.count {
            //print("chart point : \(values[i])")
            let dataEntry = ChartDataEntry(x: Double(i), y: values[i], data: times as AnyObject?)
            dataEntries.append(dataEntry)
        }
        let line1 = LineChartDataSet(entries: dataEntries, label: "Spots Available")
        line1.colors = [NSUIColor.green]
        let data = LineChartData(dataSet: line1)
        lineChart.xAxis.valueFormatter = self
        lineChart.data = data
        
        lineChart.xAxis.centerAxisLabelsEnabled = false
        //lineChart.xAxis.setLabelCount(values.count, force: true)
        
        lineChart.xAxis.labelPosition = .bottom
        lineChart.xAxis.drawLabelsEnabled = true
        lineChart.xAxis.drawLimitLinesBehindDataEnabled = true
        lineChart.xAxis.avoidFirstLastClippingEnabled = true
        
        let gradient = getGradientFilling()
        line1.fill = Fill.fillWithLinearGradient(gradient, angle: 90.0)
        line1.drawFilledEnabled = true
    }
    
    
    // Thsi function creates gradient for filling space under the line chart
    private func getGradientFilling() -> CGGradient {
        // Setting fill gradient color
        let coloTop = UIColor(red: 141/255, green: 133/255, blue: 220/255, alpha: 1).cgColor
        let colorBottom = UIColor(red: 230/255, green: 155/255, blue: 210/255, alpha: 1).cgColor
        // Colors of the gradient
        let gradientColors = [coloTop, colorBottom] as CFArray
        // Positioning of the gradient
        let colorLocations: [CGFloat] = [0.7, 0.0]
        // Gradient Object
        return CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)!
    }
    
    // A segue to send the day of the graph to the previous screen
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let button = sender as! UIButton
        if(button == backbutton){
            let driver = segue.destination as! ViewController
            let whatToPass = dateLookUp
            driver.receiver = whatToPass
        }
    }
    
    
}

// This extension allows for modifying the x-axis label of the graph
extension SecondView: IAxisValueFormatter {
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return times[Int(value) % times.count]
    }
}

