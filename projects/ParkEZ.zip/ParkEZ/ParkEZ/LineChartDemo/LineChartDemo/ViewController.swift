//
//  ViewController.swift
//  LineChartDemo
//
//  Created by Nguyen, Cong D on 11/4/19.
//  Copyright © 2019 Nguyen, Cong D. All rights reserved.
//

import UIKit
import Charts

class ViewController: UIViewController {


    @IBOutlet weak var lineChart: LineChartView!
    var dataEntries: [ChartDataEntry] = []
    
    var numbers : [Double] = [] //This is where we are going to store all the numbers. This can be a set of numbers that come from a Realm database, Core data, External API's or where ever else
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setChart(values: [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 3.0, 10.0, 20.0, 7.0, 9.0])
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    func setChart(values: [Double]) {
           lineChart.noDataText = "No data available!"
           for i in 0..<values.count {
               print("chart point : \(values[i])")
               let dataEntry = ChartDataEntry(x: Double(i), y: values[i])
               dataEntries.append(dataEntry)
           }
        let line1 = LineChartDataSet(entries: dataEntries, label: "Units Consumed")
           line1.colors = [NSUIColor.blue]
           

           let gradient = getGradientFilling()
           line1.fill = Fill.fillWithLinearGradient(gradient, angle: 90.0)
           line1.drawFilledEnabled = true

           let data = LineChartData()
           data.addDataSet(line1)
           lineChart.data = data
        
        lineChart.pinchZoomEnabled = true;
           lineChart.setScaleEnabled(false)
           lineChart.animate(xAxisDuration: 1.5)
           lineChart.drawGridBackgroundEnabled = true
           lineChart.xAxis.drawAxisLineEnabled = true
           lineChart.xAxis.drawGridLinesEnabled = true
           lineChart.leftAxis.drawAxisLineEnabled = true
           lineChart.leftAxis.drawGridLinesEnabled = true
           lineChart.rightAxis.drawAxisLineEnabled = true
           lineChart.rightAxis.drawGridLinesEnabled = true
           lineChart.legend.enabled = true
           lineChart.xAxis.enabled = true
           lineChart.leftAxis.enabled = true
           lineChart.rightAxis.enabled = true
           lineChart.xAxis.drawLabelsEnabled = true
        
        lineChart.xAxis.avoidFirstLastClippingEnabled = true
        


       }
    
    /// Creating gradient for filling space under the line chart
    private func getGradientFilling() -> CGGradient {
        // Setting fill gradient color
        let coloTop = UIColor(red: 141/255, green: 133/255, blue: 220/255, alpha: 1).cgColor
        let colorBottom = UIColor(red: 230/255, green: 155/255, blue: 210/255, alpha: 1).cgColor
        // Colors of the gradient
        let gradientColors = [coloTop, colorBottom] as CFArray
        // Positioning of the gradient
        let colorLocations: [CGFloat] = [0.7, 0.0]
        // Gradient Object
        return CGGradient.init(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: gradientColors, locations: colorLocations)!
    }

}

