//
//  WeekView.swift
//  ParkEZ
//
//  Created by Benjamin Kim on 12/1/19.
//  Copyright © 2019 Benjamin Kim. All rights reserved.
//

import UIKit
import Foundation

class WeekView: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    //object to be put in array to be referenced
    struct instance : Decodable { let Date: String; let Enter:Int; let Exit:Int }
    
    var receiver:String!
    @IBOutlet weak var enterLabel: UILabel!
    @IBOutlet weak var exitLabel: UILabel!
    @IBOutlet weak var moreInfo: UIButton!
    @IBOutlet weak var graphScreen: UIButton!
    @IBOutlet weak var dayOfWeek: UIPickerView!
    var test = [WeekView.instance]()
    var pickerData = [String]() // list of days
    var pickerData2 = [String]() // list of days
    var pickerDataAsName = [String]() // list of days as word
    var totalExits1 = [Int]() // list of total exits
    var totalEnter1 = [Int]() // list of total enters

    var selectedValue = ""//this is selected day to be accessed next view
    
    
    @IBOutlet weak var graphbtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.


        pickerDataAsName = ["Sunday - " + pickerData[0], "Monday - " + pickerData[1],"Tuesday - " + pickerData[2],"Wednesday - " + pickerData[3],"Thursday - " + pickerData[4],"Friday - " + pickerData[5],"Saturday - " + pickerData[6]]
        //path for plist
        let url = Bundle.main.url(forResource:"Data", withExtension: "plist")!
        //gets plist content
        let data = try! Data.init(contentsOf: url)
        //gets the data and decodes it to match struct
        let array = try! PropertyListDecoder().decode([instance].self, from: data)
        //puts the data into array
        test = array
        
        var numberOfExits = 0
        var numberOfEnter = 0
        for str in pickerData{
            for instance in test{
                let date = instance.Date
                let enter = instance.Enter
                let exit = instance.Exit
                if(str == date){
                    numberOfExits += exit
                    numberOfEnter += enter
                }
            }
            totalExits1.append(numberOfExits)
            totalEnter1.append(numberOfEnter)
            // reset to 0 for next loop
            numberOfExits = 0;
            numberOfEnter = 0;
        }
        enterLabel.text = String(totalEnter1[0])
        // print(totalEnter2)
        exitLabel.text = String(totalExits1[0])
        // print(totalExits2)
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // Create number of options for the picker view
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // Create the options for the picker view
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerDataAsName[row]
    }
    
    // This happens when the user picks a different option
    // The display will change based on the picked option
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch row {
        case 0:
            enterLabel.text = String(totalEnter1[0])
            // print(totalEnter2)
            exitLabel.text = String(totalExits1[0])
            // print(totalExits2)
        case 1:
            enterLabel.text = String(totalEnter1[1])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[1])
            // print(totalExits1)
        case 2:
            enterLabel.text = String(totalEnter1[2])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[2])
            // print(totalExits1)
        case 3:
            enterLabel.text = String(totalEnter1[3])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[3])
            // print(totalExits1)
        case 4:
            enterLabel.text = String(totalEnter1[4])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[4])
            // print(totalExits1)
        case 5:
            enterLabel.text = String(totalEnter1[5])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[5])
            // print(totalExits1)
        case 6:
            enterLabel.text = String(totalEnter1[6])
            // print(totalEnter1)
            exitLabel.text = String(totalExits1[6])
            // print(totalExits1)
        default:
            break
        }
        
    }
    
    // Send three arrays to the next screen
    // an array contains total entries for each day
    // an array contains total exits for each day
    // an array contains the specific date for each day
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let button = sender as! UIButton
        if(button == graphbtn){
            
            let driver = segue.destination as! WeekGraphViewController
            
            driver.entries = totalEnter1
            driver.exits = totalExits1
            driver.date = pickerData
        }
    }
    
}
