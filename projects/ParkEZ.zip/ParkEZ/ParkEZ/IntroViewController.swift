//
//  IntroViewController.swift
//
//
//  Created by Benjamin Kim on 11/30/19.
//

import UIKit

class IntroViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var selectDate: UIPickerView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    @IBOutlet weak var Button: UIButton!
    var pickerDays = [String]() // list of days
    var pickerWeeks = [String]() // list of weeks
    var selectedValue = "" // this is selected day to be accessed next view
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Input data for picker view
        pickerDays = ["11/03/19", "11/04/19", "11/05/19", "11/06/19", "11/07/19", "11/08/19","11/09/19","11/10/19", "11/11/19", "11/12/19", "11/13/19", "11/14/19", "11/15/19","11/16/19"]
        pickerWeeks = ["Week 1", "Week 2",]
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // This function changes data in the Picker View based on selected segment
    @IBAction func changeValueSC(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            self.selectDate.reloadComponent(0)
        case 1:
            self.selectDate.reloadComponent(0)
        default:
            break
            
        }
    }
    
    // Display the number of columns of data in the picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // Depend on the current segmented control, display the number of options accordingly
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            return pickerDays.count
        case 1:
            return pickerWeeks.count
        default:
            return 0
        }
    }
    
    // Depend on the current segmented control, display the options accordingly
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            return pickerDays[row]
        case 1:
            return pickerWeeks[row]
            
        default:
            return ""
        }
    }
    
    // Depend on the current segmented control, the button will lead to a different scene
    @IBAction func nextButtonPressed(_ sender: Any) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            selectedValue = pickerDays[selectDate.selectedRow(inComponent: 0)]
            self.performSegue(withIdentifier: "day", sender: nil)
        case 1:
            selectedValue = pickerWeeks[selectDate.selectedRow(inComponent: 0)]
            self.performSegue(withIdentifier: "week", sender: nil)
        default:
            break
        }
    }
    
    // Seque for the next screen
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            let driver = segue.destination as! ViewController
            let whatToPass = selectedValue
            driver.receiver = whatToPass
        case 1:
            let driver = segue.destination as! WeekView
            let whatToPass = selectedValue
            if whatToPass == "Week 1"{
            driver.receiver = whatToPass
                let first7 = Array(pickerDays.prefix(7))
                driver.pickerData = first7
            } else if whatToPass == "Week 2"{
                driver.receiver = whatToPass
                let last7 = Array(pickerDays.suffix(7))
                driver.pickerData = last7
            }
        default:
            break
        }
        
    }
    
}
